# SortOrder

### Description

The order (e.g., chronological or alphabetical) in which results from a request are returned.

## Properties
Name | Type
------------ | -------------
**DESC** | string
**ASC** | string

Note: All properties are protected and only accessed via getters and setters.

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

