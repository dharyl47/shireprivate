# V1MerchantBusinessType

### Description


**Note: This model is deprecated.**

## Properties
Name | Type
------------ | -------------
**ACCOUNTING** | string
**APPAREL_AND_ACCESSORY_SHOPS** | string
**ART_DEALERS_GALLERIES** | string
**ART_DESIGN_AND_PHOTOGRAPHY** | string
**BAR_CLUB_LOUNGE** | string
**BEAUTY_AND_BARBER_SHOPS** | string
**BOOK_STORES** | string
**BUSINESS_SERVICES** | string
**CATERING** | string
**CHARITABLE_SOCIAL_SERVICE_ORGANIZATIONS** | string
**CHARITIBLE_ORGS** | string
**CLEANING_SERVICES** | string
**COMPUTER_EQUIPMENT_SOFTWARE_MAINTENANCE_REPAIR_SERVICES** | string
**CONSULTANT** | string
**CONTRACTORS** | string
**DELIVERY_SERVICES** | string
**DENTISTRY** | string
**EDUCATION** | string
**FOOD_STORES_CONVENIENCE_STORES_AND_SPECIALTY_MARKETS** | string
**FOOD_TRUCK_CART** | string
**FURNITURE_HOME_AND_OFFICE_EQUIPMENT** | string
**FURNITURE_HOME_GOODS** | string
**HOTELS_AND_LODGING** | string
**INDIVIDUAL_USE** | string
**JEWELRY_AND_WATCHES** | string
**LANDSCAPING_AND_HORTICULTURAL_SERVICES** | string
**LANGUAGE_SCHOOLS** | string
**LEGAL_SERVICES** | string
**MEDICAL_PRACTITIONERS** | string
**MEDICAL_SERVICES_AND_HEALTH_PRACTITIONERS** | string
**MEMBERSHIP_ORGANIZATIONS** | string
**MUSIC_AND_ENTERTAINMENT** | string
**OTHER** | string
**OUTDOOR_MARKETS** | string
**PERSONAL_SERVICES** | string
**POLITICAL_ORGANIZATIONS** | string
**PROFESSIONAL_SERVICES** | string
**REAL_ESTATE** | string
**RECREATION_SERVICES** | string
**REPAIR_SHOPS_AND_RELATED_SERVICES** | string
**RESTAURANTS** | string
**RETAIL_SHOPS** | string
**SCHOOLS_AND_EDUCATIONAL_SERVICES** | string
**SPORTING_GOODS** | string
**TAXICABS_AND_LIMOUSINES** | string
**TICKET_SALES** | string
**TOURISM** | string
**TRAVEL_TOURISM** | string
**VETERINARY_SERVICES** | string
**WEB_DEV_DESIGN** | string

Note: All properties are protected and only accessed via getters and setters.

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

