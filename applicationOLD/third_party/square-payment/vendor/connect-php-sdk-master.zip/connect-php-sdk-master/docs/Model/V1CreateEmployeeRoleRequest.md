# V1CreateEmployeeRoleRequest

### Description



## Properties
Name | Getter | Setter | Type | Description | Notes
------------ | ------------- | ------------- | ------------- | ------------- | -------------
**employee_role** | getEmployeeRole() | setEmployeeRole($value) | [**\SquareConnect\Model\V1EmployeeRole**](V1EmployeeRole.md) | An EmployeeRole object with a name and permissions, and an optional owner flag. | [optional] 

Note: All properties are protected and only accessed via getters and setters.

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

