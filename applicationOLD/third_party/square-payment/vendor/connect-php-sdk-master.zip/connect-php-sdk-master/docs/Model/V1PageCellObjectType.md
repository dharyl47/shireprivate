# V1PageCellObjectType

### Description


**Note: This model is deprecated.**

## Properties
Name | Type
------------ | -------------
**ITEM** | string
**DISCOUNT** | string
**CATEGORY** | string
**PLACEHOLDER** | string

Note: All properties are protected and only accessed via getters and setters.

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

