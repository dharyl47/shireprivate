# DayOfWeek

### Description

Indicates the specific day  of the week.

## Properties
Name | Type
------------ | -------------
**SUN** | string
**MON** | string
**TUE** | string
**WED** | string
**THU** | string
**FRI** | string
**SAT** | string

Note: All properties are protected and only accessed via getters and setters.

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

