# TenderType

### Description

Indicates a tender's type.

## Properties
Name | Type
------------ | -------------
**CARD** | string
**CASH** | string
**THIRD_PARTY_CARD** | string
**SQUARE_GIFT_CARD** | string
**NO_SALE** | string
**OTHER** | string

Note: All properties are protected and only accessed via getters and setters.

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

