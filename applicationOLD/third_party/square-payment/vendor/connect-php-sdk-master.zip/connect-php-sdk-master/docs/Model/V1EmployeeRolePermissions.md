# V1EmployeeRolePermissions

### Description



## Properties
Name | Type
------------ | -------------
**REGISTER_ACCESS_SALES_HISTORY** | string
**REGISTER_APPLY_RESTRICTED_DISCOUNTS** | string
**REGISTER_CHANGE_SETTINGS** | string
**REGISTER_EDIT_ITEM** | string
**REGISTER_ISSUE_REFUNDS** | string
**REGISTER_OPEN_CASH_DRAWER_OUTSIDE_SALE** | string
**REGISTER_VIEW_SUMMARY_REPORTS** | string

Note: All properties are protected and only accessed via getters and setters.

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

