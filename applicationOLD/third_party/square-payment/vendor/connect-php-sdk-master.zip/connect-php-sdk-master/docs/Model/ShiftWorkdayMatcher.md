# ShiftWorkdayMatcher

### Description

Defines the logic used to apply a workday filter.

## Properties
Name | Type
------------ | -------------
**START_AT** | string
**END_AT** | string
**INTERSECTION** | string

Note: All properties are protected and only accessed via getters and setters.

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

