# CustomerSortField

### Description

Indicates the sort criteria for a list of Customers.

## Properties
Name | Type
------------ | -------------
**DEFAULT** | string
**CREATED_AT** | string

Note: All properties are protected and only accessed via getters and setters.

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

