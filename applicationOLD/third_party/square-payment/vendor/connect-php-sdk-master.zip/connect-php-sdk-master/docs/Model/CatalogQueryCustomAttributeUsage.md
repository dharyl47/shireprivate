# CatalogQueryCustomAttributeUsage

### Description



## Properties
Name | Getter | Setter | Type | Description | Notes
------------ | ------------- | ------------- | ------------- | ------------- | -------------
**custom_attribute_definition_ids** | getCustomAttributeDefinitionIds() | setCustomAttributeDefinitionIds($value) | **string[]** |  | [optional] 
**has_value** | getHasValue() | setHasValue($value) | **bool** |  | [optional] 

Note: All properties are protected and only accessed via getters and setters.

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

